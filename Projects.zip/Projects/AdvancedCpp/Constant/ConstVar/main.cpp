// C++ program to demonstrate the
// the above concept
#include <iostream>

using namespace std;

// Driver Code
int main()
{

    // const int x; CTE error
    // x = 9; CTE error (compile-time error)
    const int y = 10;
    cout << y;

    return 0;
}
