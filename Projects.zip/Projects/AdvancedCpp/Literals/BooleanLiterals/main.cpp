#include <iostream>
using namespace std;

int main()
{
    const bool isTrue = true;
    const bool isFalse = false;

    cout << "isTrue? "
        << isTrue << "\n";
    cout << "isFalse? "
        << isFalse << "\n";

    return 0;
}
