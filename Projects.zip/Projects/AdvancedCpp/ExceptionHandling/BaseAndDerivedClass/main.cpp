// C++ Program to demonstrate a catching of
// Derived exception and printing it successfully
#include <iostream>
using namespace std;

class Base {};
class Derived : public Base {};
int main()
{
    Derived d;
    // Some other functionalities
    try {
        // Monitored code
        throw d;
    }
    /*
    catch (Base b) {
        cout << "Caught Base Exception";
    }
    catch (Derived d) {
        // This 'catch' block is NEVER executed
        cout << "Caught Derived Exception";
    }
    // Caught Base Exception
    */
    catch (Derived d) {
        cout << "Caught Derived Exception";
    }
    catch (Base b) {
        cout << "Caught Base Exception";
    }
    // Caught Derived Exception

    getchar(); // To read the next character

    return 0;
}
